module.exports = {
    publicPath: '/pwa-test/'
}